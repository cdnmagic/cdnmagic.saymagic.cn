# -*- coding: utf-8 -*-
LOUDWISE_AppKey = 'MyHostKey'
CLOUDWISE_HostId = 'MyHostId'
CLOUDWISE_SendProxy = 'http://127.0.0.1:26789'
CLOUDWISE_IsEnable = True
CLOUDWISE_LogFile = '/tmp/smartagent.log'
CLOUDWISE_LogEnable = False
CLOUDWISE_DataPath='/tmp/Tsb_data'
CLOUDWISE_SetEnv = ''


