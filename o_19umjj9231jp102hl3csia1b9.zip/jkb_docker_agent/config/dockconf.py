# -*- coding: utf-8 -*-

get_config_url='http://www.jiankongbao.com/docker/task/info/'

get_config_freq=60

support_os=['CentOS','Ubuntu']

JKB_TASK_ID=75
JKB_ACCOUNT_ID=205268
JKB_USER_ID=324479

