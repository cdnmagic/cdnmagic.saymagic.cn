# -*- coding: utf-8 -*-
#!/usr/bin/env python

from config import dockconf
from config import Tsb_config
import sys
import os
import socket
import fcntl
import struct
import subprocess
import threading
import traceback
import time
import logging
import commands
import datetime
try:
    from  urllib import parse
except ImportError:
    import urllib as parse
    
try:
    import urllib2
except ImportError:
    import urllib.request as urllib2

try:
    import json
except ImportError:
    import simplejson as json

class Task():
    def __init__(self):
        self.task_id=0
        self.frequency=120
        self.status=1
        self.running=True
        
        

class DockerProcess(threading.Thread):
    def __init__(self,task):
        self.task=task
        self.ip=self.getLocalIp()
        self.os_info=self.get_os()
        msg = commands.getoutput("chmod 777 bin/"+self.os_info+"/docker_py")
        threading.Thread.__init__(self)
        
    
    def run(self):
        try:
            while self.task.running:
                try:
                    cur=time.time()
                    self.getData()
                    reload(Tsb_config)
                    if not Tsb_config.CLOUDWISE_IsEnable:
                        self.task.running=False
                    time.sleep(self.task.frequency-(time.time()-cur))
                except Exception :
                    time.sleep(self.task.frequency)
                    log_error(traceback.format_exc())
        finally:
            self.task.running=False
            print('DockerProcess exit')
            log_info('DockerProcess exit')

    def getData(self):
        if self.task.status == 3:
            log_info('task is stopped!')
            return False
        if self.task.status == 4:
            log_info('task is deleted!')
            self.task.running=False
            return False
        
        cmd='./bin/'+self.os_info+'/docker_py'
        returnstr=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE, shell=True)
        data = returnstr.stdout.read()
        data=eval(data)
        if int(data['code'])!=200:
            log_error('get data  error:'+data['data'])
            return False
            
        data['data']['account_id']=dockconf.JKB_ACCOUNT_ID
        data['data']['task_id']=dockconf.JKB_TASK_ID
        data['data']['user_id']=dockconf.JKB_USER_ID
        data['data']['service_type']=216
        data['data']['server_ip']=self.ip
        
        #post data
        data=json.dumps(data['data'])
        
        #log_info(data)
        
        dat={}
        dat['value']=data
        dat=json.dumps(dat)
        parms = {'Content':''+dat,'ApiEnum':'1','RoutingKey':'agentTopic','ObjID':''}
	parms=json.dumps(parms,ensure_ascii=False)
        url = Tsb_config.CLOUDWISE_SendProxy+'/send'
        try:
	    req=urllib2.Request(url , parms)
	    req.add_header('Content-Type','text/plain')
            res =  urllib2.urlopen(req)
            command = res.read()
            res.close()
        except Exception :
            print('data post error:'+url)
            log_error('data post error:'+url)
            


    def getLocalIp(self):
        ifname="eth0"
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        return socket.inet_ntoa(fcntl.ioctl(sock.fileno(), 0x8915,struct.pack('256s', ifname[:15]))[20:24])

    def get_os(self):
        msg = commands.getoutput("cat /etc/issue")
        if not msg[:6] in dockconf.support_os:
            print('do not support '+msg[:6])
            log_error('do not support '+msg[:6])
            self.task.running=False
            return False
        return msg[:6].lower()
            
            
class DockerConfig(threading.Thread):
    def __init__(self,task):
        self.freq=dockconf.get_config_freq
        self.task=task
        threading.Thread.__init__(self)
    
    def run(self):
        try:
            while self.task.running:
                try:
                    self.get_config()
                    time.sleep(self.freq)
                except Exception :
                    time.sleep(self.freq)
                    log_error(traceback.format_exc())
        finally:
            print('DockerConfig exit')
            log_info('DockerConfig exit')
            
    def get_config(self):
        url = dockconf.get_config_url+str(dockconf.JKB_TASK_ID)+'/'+str(dockconf.JKB_USER_ID)+'/'+str(dockconf.JKB_ACCOUNT_ID)
        res =  urllib2.urlopen(url)
        redata = res.read()
        res.close()
        if redata=='':
            self.task.running=False
            log_info('task info is none!')
            return False
        redata=eval(redata)
        self.task.frequency=int(redata['task_frequency'])*60
        self.task.status=int(redata['task_status'])
        

            
class DockerPing(threading.Thread):
    def __init__(self,task):
        self.task = task
        self.freq=5
        threading.Thread.__init__(self)
    
    def run(self):
        try:
            while self.task.running:
                try:
                    self.agentPing()
                    time.sleep(self.freq)
                except Exception :
                    time.sleep(self.freq)
                    log_error(traceback.format_exc())
        finally:
            print('DockerPing exit')
            log_info('DockerPing exit')

    def agentPing(self):
        pingPath='tmp/dockerPing.txt'
        pf = open(pingPath,'w')
        pf.write("%s\n" % time.time())
        pf.close()


def date(unixtime, format = '%m/%d/%Y %H:%M'):
    d = datetime.datetime.fromtimestamp(unixtime)
    return d.strftime(format)

def log_info(strs):
    logger = logging.getLogger('dockerLog')
    FileHandler = logging.FileHandler('log/'+date(time.time(), format = '%Y-%m-%d')+'.log')
    FileHandler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
    logger.addHandler(FileHandler)
    logger.setLevel(logging.INFO)
    logger.info(strs)
    logger.removeHandler(FileHandler)
    FileHandler.close()

def log_error(strs):
    logger = logging.getLogger('dockerLog')
    FileHandler = logging.FileHandler('log/'+date(time.time(), format = '%Y-%m-%d')+'.log')
    FileHandler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
    logger.addHandler(FileHandler)
    logger.setLevel(logging.INFO)
    logger.error(strs)
    logger.removeHandler(FileHandler)
    FileHandler.close()

    
if __name__ == "__main__":
    Pid = os.getpid()
    if  len(sys.argv)!=2:
        print("usage: %s start|stop|restart|status" % sys.argv[0])
        sys.exit(1)
    if 'start' == sys.argv[1] or 'restart' == sys.argv[1]:
        if 'restart' == sys.argv[1]:
            msg = commands.getoutput("ps -ef | grep dockerAgent | grep -v grep|grep -v "+str(Pid)+"|awk '{print $2}'| xargs kill -s 9")
        msg = commands.getoutput("ps -ef | grep dockerAgent | grep -v grep|grep -v "+str(Pid)+"|awk '{print $2}'")
        if msg!='':
            print('agent has been started, the process ID：'+str(msg))
            log_info('agent has been started, the process ID：'+str(msg))
            sys.exit(1)
        log_info('agent is startting, the process ID：'+str(Pid))
        task = Task()
        dockerProcess = DockerProcess(task)
        dockerProcess.setName('dockerProcess')
        dockerProcess.setDaemon(True)
        dockerProcess.start()
        dockerConfig = DockerConfig(task)
        dockerConfig.setName('dockerConfig')
        dockerConfig.setDaemon(True)
        dockerConfig.start()
        dockerPing=DockerPing(task)
        dockerPing.setName('DockerCheck')
        dockerPing.setDaemon(True)
        dockerPing.start()
        while task.running:
            time.sleep(1)
        log_info('agent quit!')
            
    elif 'stop' == sys.argv[1]:
        msg = commands.getoutput("ps -ef | grep dockerAgent | grep -v grep|grep -v "+str(Pid)+"|awk '{print $2}'| xargs kill -s 9")
        if msg =='':
            print('Successful process closes')
            log_info('Successful process closes')
        else:
            print('The process does not exist')
            log_info('The process does not exist')
    
    elif 'status' == sys.argv[1]:
        msg = commands.getoutput("ps -ef | grep dockerAgent | grep -v grep|grep -v "+str(Pid)+"|awk '{print $2}'")
        if msg !='':
            print('agent has been started, the process ID：'+str(msg))
            log_info('agent has been started, the process ID：'+str(msg))
        else:
            print('agent has been stoped')
            log_info('agent has been stoped')
        sys.exit(1)
    else:
        print("usage: %s start|stop|restart|status" % sys.argv[0])

