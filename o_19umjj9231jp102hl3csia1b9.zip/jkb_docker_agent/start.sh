#!/bin/bash
PATH=/usr/local/mysql/bin:/sbin:/usr/sbin:/usr/local/sbin:/root/bin:/usr/local/bin:/usr/bin:/bin:/usr/X11R6/bin:/usr/games:/usr/lib/mit/bin:/usr/lib/mit/sbin
CWD=`cd $(dirname $0);pwd`
cd $CWD;
nohup python dockerAgent.py start >log/nohup.log 2>&1 &
